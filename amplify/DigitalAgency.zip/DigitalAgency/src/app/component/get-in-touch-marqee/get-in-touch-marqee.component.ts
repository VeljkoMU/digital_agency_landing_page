import { Component } from '@angular/core';

@Component({
  selector: 'app-get-in-touch-marqee',
  standalone: true,
  imports: [],
  templateUrl: './get-in-touch-marqee.component.html',
  styleUrl: './get-in-touch-marqee.component.css'
})
export class GetInTouchMarqeeComponent {

}
