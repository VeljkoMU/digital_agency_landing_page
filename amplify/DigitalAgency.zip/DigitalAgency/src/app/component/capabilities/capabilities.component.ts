import { Component } from '@angular/core';

@Component({
  selector: 'app-capabilities',
  standalone: true,
  imports: [],
  templateUrl: './capabilities.component.html',
  styleUrl: './capabilities.component.css'
})
export class CapabilitiesComponent {

}
